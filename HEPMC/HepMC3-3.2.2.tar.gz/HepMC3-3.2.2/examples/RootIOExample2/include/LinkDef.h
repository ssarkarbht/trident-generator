#ifdef __CINT__

#pragma link C++ class MyClass+;
#pragma link C++ class MyRunClass+;
#pragma link C++ class HepMC3::GenEvent-;
#pragma link C++ class HepMC3::GenRunInfo-;

#endif
